# Development journey

Retrospective prepared on 27 October 2026 from saved source through website version 25 and the development conversation. Milestones group related work; they do not assert exact original commit dates.

| Milestone | Need | Response and learning |
| --- | --- | --- |
| Learning foundation | More than a few isolated lessons | Expanded to 100 adult lessons with worked examples and practice; navigation became essential as content grew. |
| Curriculum pathways | Appropriate school-level content | Separate WAEC and Cambridge routes for Years 7–12; progress had to remain isolated between pathways. |
| Identity and saved work | Recognition and continuity | Added profiles, unique usernames and saved progress; account switching and failed saves required checks. |
| Teacher preparation | Reusable classroom materials | Added slides, plans, PDFs and original mocks; feedback led to deeper explanations, diagrams and examples. |
| Resource protection | Ordinary accounts could reach subscriber content | Introduced entitlement-based access; authentication alone was insufficient. |
| School adoption | Organised access for staff | Added school membership and resource workspaces. |
| Independent tutors | Access outside a school licence | Added personal plans at ₦15,000 monthly, ₦40,000 termly and ₦100,000 annually. |
| Operational administration | Find users, invoices and payment instructions | Reorganised controls around people, metrics, invoices, subscriptions and billing. |
| Delegation | More administrators without losing owner control | Separated the main administrator from additional administrators and enforced role boundaries. |
| Topic evaluation | Assess understanding of one topic | Added independent and teacher-assigned topic tests with results and reports. |
| Public identity | Explain ownership | Added the founder biography and ownership information. |
| Usability revision | Feedback that the platform was hard to use | Improved beginner guidance, navigation and resuming work; usability became an ongoing concern. |
| Competition centre | Control a full event privately | Added stages, entrant approval, server timing and scoring, tie-breaks and progression. |
| Named competition | Tougher senior papers | Added 530 questions in seven papers, extended the question limit to 100 and allowed longer timers. |
| Fairness and physical events | Verify eligibility and supervise finals | Discussed age checks and event workflows; these remain roadmap items rather than completed claims. |
| Portfolio | Explain the complete process | Prepared this separate sanitised documentation package. |

### Working method

Identify a learner or owner problem, describe intended behaviour, implement a bounded change, check both permitted and forbidden actions, deploy, and revise after feedback. AI assisted implementation and content generation; human educational review remains necessary.

### Honest history

The first GitHub documentation commit should use the actual publication date. Earlier work belongs in this retrospective. Future changes should use genuine commits, issues and release notes rather than backdated history.
