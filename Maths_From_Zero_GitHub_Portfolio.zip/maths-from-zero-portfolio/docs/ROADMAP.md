# Status and roadmap

Snapshot: 27 October 2026, following website version 25.

| Item | Status | What remains |
| --- | --- | --- |
| Learning, profiles, teacher library, workspaces | Implemented | Ongoing content and usability review. |
| Invoice and subscription administration | Implemented | Not represented as automated payment-gateway reconciliation. |
| Competition centre | Implemented | Owner review, scheduling and publication of each event. |
| Prof Abayomi Arigbabu competition | Private senior-school draft | Review the seven papers and event rules before publishing. |
| Documentary age verification | Proposed | Fixed cutoff, private review, confirmed school contacts, decisions and appeals. |
| Physical-final management | Proposed | Venue, attendance, admission, judges’ scores and result approval. |
| Traffic capacity | Unverified at large-event scale | Representative concurrent-user tests and recovery checks. |
| Beginner usability | Improved; further evaluation proposed | Observe first-time users and retest friction points. |
| Accessibility | Further assessment proposed | Keyboard, screen-reader, contrast and mobile evaluation. |
| Custom domain | Discussed | Do not assume a purchase or attachment has happened. |
| AI tutor | Conditional | Configuration, enabled settings and API credits. |

### Named draft structure

| Stage | Questions | Draft minutes |
| --- | --- | --- |
| Practice | 50 | 120 |
| Qualification | 60 | 150 |
| Groups | 70 | 180 |
| Quarter-finals | 80 | 200 |
| Semi-finals | 90 | 225 |
| Third-place playoff | 80 | 200 |
| Final | 100 | 240 |

These are prepared paper counts, not evidence that registration is open or that an event has taken place. The name alone does not establish endorsement by the named individual.
