# Testing and evidence

### Application evidence

The source and development record were inspected. The full production suite was not rerun solely for this documentation task. Tests described below exist in the private repository; this public package does not include private SQL fixtures or production access.

| Coverage | Representative private evidence |
| --- | --- |
| Learning and navigation | `test-course.cjs`, `test-school.cjs`, `test-learning-ui.cjs` |
| Identity and progress isolation | `test-auth-sync.cjs`, `test-profile.cjs` |
| Main-administrator protection | `test-admin-team.sql`, `test-admin-team-ui.cjs` |
| Resources and submissions | `test-teachers.mjs`, `test-teacher-submissions.cjs` |
| School/tutor access | `test-school-workspaces.sql`, `test-personal-tutors.sql` |
| Invoice control | `test-admin-control.sql`, `test-admin-control-ui.cjs` |
| Topic tests and reports | `test-topic-assessments.sql`, `test-topic-ui.cjs` |
| Competition progression | `test-competitions.sql`, `test-competition-ui.cjs` |
| Long papers and content checks | `test-arigbabu.sql`, `check-arigbabu-papers.py` |

The recorded competition checks passed for roles, drafts, grading, deadlines, tie-breaks and advancement. The long-paper checks passed for 100 questions, 101-question rejection, saving/resuming and timing. Content generation checked 530 distinct texts across 80 parameterised problem families; these are not 530 unrelated mathematical techniques. Human review of difficulty, wording and curriculum suitability remains necessary.

### Portfolio evidence

Run `node --test examples/csv-export.test.mjs` for the included illustrative export helper. It uses invented values and no credentials. This checks the helper, not production permissions or the whole platform.

### Limits

No independent security certification, accessibility audit, load-test report, verified learning-outcome study or revenue result is supplied. Registration limits do not establish concurrent capacity. Passing tests establish their assertions, not the absence of all defects.
