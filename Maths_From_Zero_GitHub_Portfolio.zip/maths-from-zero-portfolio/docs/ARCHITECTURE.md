# Architecture

Simplified implementation overview. Credentials, operational identifiers, full schemas and records are deliberately omitted.

```mermaid
flowchart TD
  U[Students, teachers and administrators] --> B[Browser interface]
  B --> W[Worker assets and endpoints]
  B --> A[Supabase authentication]
  B --> R[Authorised database operations]
  A --> R
  R --> D[Private PostgreSQL records]
  R --> F[Controlled resource access]
  W --> T[Configured tutor service]
```

| Component | Responsibility | Representative private source |
| --- | --- | --- |
| Student interface | Lessons, navigation and progress | `app.js`, `learning-ui.js`, `school.js` |
| Identity | Accounts, profiles and session changes | `auth.mjs` |
| Teacher/workspace modules | Resource discovery and membership operations | `teachers.mjs`, `schools.mjs`, `tutors.mjs` |
| Administration | Reporting and privileged controls | `admin.mjs`, `admin-control-ui.mjs` |
| Competitions | Private administration and participant attempts | `competitions.mjs` |
| Worker | Explicit asset allowlist and selected endpoints | `worker/index.mjs`, `scripts/build-worker.mjs` |
| Database functions | Role checks, ownership, entitlements and grading | Private SQL definitions |
| Content generation | Repeatable material and paper preparation | Private Python/JavaScript generators |

### Trust boundaries

1. Hiding a link improves navigation; the server still checks authority.
2. Being authenticated does not grant access to all teaching resources.
3. Competition metadata, question access and answer keys have different visibility rules.
4. Server deadlines and stored answers determine grading; client score claims are not authoritative.
5. Publication, stage opening, result release and advancement are separate organiser decisions.
6. Private build inputs are excluded from the public Worker asset allowlist.

The inspected application manifest uses Supabase client 2.118.0 and esbuild 0.28.2. These are snapshot facts, not permanent version recommendations. This architecture description is not an independent security audit.
