# Case studies

## 1. Protecting subscriber resources

**Problem:** An ordinary account could initially access materials intended for subscribers, weakening the commercial boundary.

**Decision:** Enforce entitlements on the server, with distinct school and personal-tutor access and intentionally public samples.

**Approach:** Discover resources through the teacher library; check access before download; distinguish teacher submission from administrative publication. Exclude private library files from ordinary public asset delivery.

**Evidence:** Recorded tests cover locked labels, public samples, authorised actions, session clearing, upload ownership and attempted self-publication.

**Limit:** Access control does not stop an authorised person copying a downloaded document. Content rights and operational entitlement records still need review.

**Lesson:** Authentication establishes identity; entitlement establishes access.

## 2. Useful administration and controlled delegation

**Problem:** The owner needed to find invoices, supply payment instructions, track people and delegate work without surrendering main-account control.

**Decision:** Organise the dashboard around operational tasks and distinguish the main administrator from additional administrators.

**Approach:** Dedicated views for accounts, invoices, subscriptions, schools, resources, billing and activity. Protect administrator management and competition control with main-only checks. Keep invoice issuance distinct from payment verification.

**Evidence:** Recorded checks cover invoice totals and filtering, escaped customer content, session clearing, protected owner access and ordinary-account rejection.

**Limit:** Recorded metrics are not necessarily anonymous visits, continuous online presence or accounting revenue. No fabricated business outcomes are included.

**Lesson:** An operational dashboard should help the owner decide what needs attention while protecting the actions behind it.

## 3. A competition as a controlled sequence

**Problem:** A complete competition needed private preparation, fair progression and increasingly rigorous papers of up to 100 questions.

**Decision:** Separate publication, opening rounds, releasing results and confirming advancement. Keep answer keys and grading under server control.

**Approach:** Practice, qualification, groups, knockout stages, optional third place and a final. Approved entrants receive timed attempts with saved answers. Tied advancement boundaries require a tie-break. Supporting 100 questions required both backend validation and editor changes.

**Evidence:** Recorded transactional checks cover drafts, roles, question redaction, resume, deadlines, server grading, consent-aware names, groups, knockout advancement and champion confirmation. Long-paper tests cover saving 100 answers, four-hour timing and rejecting 101 questions.

**Limit:** A recorded score is not proof of independent work. Documentary age checks, physical-final management and representative concurrency testing remain separate requirements.

**Lesson:** Competition software must model organiser decisions and fairness rules, not only a leaderboard.

## Usability follow-up

Feedback from less technical users led to clearer guidance and resuming work. The next useful evaluation is to observe a first-time student finding a lesson, attempting practice and returning to progress without help. This evaluation is proposed; no usability completion rate is invented here.
