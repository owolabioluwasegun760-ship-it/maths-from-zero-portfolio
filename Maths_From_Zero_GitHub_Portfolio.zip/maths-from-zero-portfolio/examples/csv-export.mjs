// Adapted illustrative helper, not a complete production security control.
export function csvCell(value) {
 const text=String(value??'').replace(/^[=+\-@\t\r]/,"'$&");
 return '"'+text.replaceAll('"','""')+'"';
}
export function toCsv(rows) {return rows.map(r=>r.map(csvCell).join(',')).join('\r\n');}
