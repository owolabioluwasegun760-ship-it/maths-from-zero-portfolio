import test from 'node:test';
import assert from 'node:assert/strict';
import {csvCell,toCsv} from './csv-export.mjs';
test('quotes delimiters and embedded quotes',()=>{
 assert.equal(csvCell('A, B'),'"A, B"');
 assert.equal(csvCell('Say "hello"'),'"Say ""hello"""');
});
test('prefixes recognised formula-like values',()=>{
 for(const p of ['=','+','-','@','\t','\r']) assert.equal(csvCell(p+'sample'),'"\''+p+'sample"');
});
test('exports invented records and empty values',()=>{
 assert.equal(toCsv([['Participant','Score'],['Example learner',null]]),'"Participant","Score"\r\n"Example learner",""');
});
