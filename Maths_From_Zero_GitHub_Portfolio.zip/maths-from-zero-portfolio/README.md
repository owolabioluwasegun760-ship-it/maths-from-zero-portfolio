# Maths From Zero
## Building a mathematics learning and school competition platform

![Maths From Zero](assets/logo.png)

Maths From Zero brings guided mathematics lessons, independent practice, teacher resources, school workspaces and staged competitions into one platform. This portfolio explains its development and the decisions behind it.

**Product owner and education lead:** Oluwasegun Solomon Owolabi, Founder & CEO, as identified on the platform’s public founder page. Implementation used ChatGPT/Codex assistance; see [contributions](docs/CONTRIBUTIONS.md).

[Visit the platform](https://maths-from-zero-learning.okeabiodun81.chatgpt.site) · [Build journey](docs/BUILD-JOURNEY.md) · [Architecture](docs/ARCHITECTURE.md) · [Case studies](docs/CASE-STUDIES.md) · [Testing](docs/TESTING.md)

> This is a documentation portfolio, not the production application repository. Earlier work is described retrospectively; no historical commits have been reconstructed. Private teaching resources, participant data and competition answers are excluded.

### The problem

Students need accessible explanations and practice. Teachers need useful preparation materials and ways to evaluate understanding. Schools need organised workspaces, while the platform owner needs control over accounts, subscriptions, invoices and protected resources.

### Delivered features

| Area | Capability |
| --- | --- |
| Learning | 100 adult lessons and separate WAEC and Cambridge pathways with 108 lessons each across Years 7–12. |
| Assessment | Topic practice, independent progress, four original 100-question progression forms and teacher-assigned topic assessments. |
| Accounts | Email authentication, confirmation, recovery and unique usernames. |
| Teacher resources | A protected library for slides, Word plans, PDFs and original mock papers. |
| School workspaces | School membership, staff access and resource organisation. |
| Personal tutors | Subscription workflow with monthly, termly and annual plans. |
| Administration | Account directory, metrics, invoice inbox, billing details, subscriptions and resource controls. |
| Administrative roles | A protected main administrator manages additional administrators. |
| Competitions | Private drafts, publication approval, timed saved attempts, server grading, tie-breaks and confirmed advancement. |
| Named senior competition | A private Prof Abayomi Arigbabu draft with 530 original questions across seven rounds, increasing from 50 to 100. |

These are content and feature counts, not usage statistics or evidence of learning outcomes. Curriculum labels do not imply official exam-board endorsement.

### Technology

HTML, CSS and JavaScript provide the interface. Supabase supports authentication, PostgreSQL and protected resource services. A Worker serves an explicit set of assets and selected server endpoints through Sites hosting. esbuild bundles browser modules; Python and JavaScript scripts prepare educational content. JavaScript and transactional SQL checks cover important workflows.

### Engineering highlights

- Server permissions back up interface visibility.
- A valid login is distinct from entitlement to subscriber resources.
- Competition publication is distinct from opening rounds and releasing results.
- The server derives marks from saved answers rather than trusting a client-submitted score.
- Beginner navigation was revised after feedback from less technical users.

### Explore the work

- [Development journey](docs/BUILD-JOURNEY.md)
- [Architecture and trust boundaries](docs/ARCHITECTURE.md)
- [Three case studies](docs/CASE-STUDIES.md)
- [Testing and evidence limits](docs/TESTING.md)
- [Feature status and roadmap](docs/ROADMAP.md)
- [Human contribution and AI assistance](docs/CONTRIBUTIONS.md)
- [Future development journal](docs/JOURNAL.md)
- [GitHub publication guide](PUBLISHING.md)
- [Rights notice](NOTICE.md)

### Current boundaries

Documentary age verification and school confirmation are proposed, not implemented. Physical-final event management is proposed. Large-event concurrency has not been benchmarked. Guaranteed anti-cheating, independent security certification and automated payment-gateway reconciliation are not claimed. AI tutoring depends on configuration and available API credits.

This portfolio contains no complete runnable production application. The small [CSV export example](examples/csv-export.mjs) is adapted to demonstrate one implementation detail using invented values. Run it with `node --test examples/csv-export.test.mjs`.
