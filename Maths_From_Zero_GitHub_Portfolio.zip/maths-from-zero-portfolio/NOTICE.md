# Rights notice

The public platform identifies Maths From Zero as owned by Oluwasegun Owolabi, with Oluwasegun Solomon Owolabi as Founder & CEO.

This package is intended for portfolio review. It grants no open-source licence to the platform, branding, resources or competition papers. Full operational source and protected materials are not included. This notice is not a legal opinion or a substitute for licensing advice.
