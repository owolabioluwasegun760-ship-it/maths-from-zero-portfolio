## What changed and why?

## Validation and limits

- [ ] Status claims match evidence.
- [ ] Local links and code example checks passed.
- [ ] No secrets, participant data, protected resources or answer banks added.
- [ ] Retrospective work and AI assistance are accurately described.
