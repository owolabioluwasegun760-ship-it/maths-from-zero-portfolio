# Publication boundaries

Do not add credentials, environment files, participant records, invoices, identity documents, protected resources or competition answer banks. Do not report private information in public issues. For a production concern, use the platform’s published support contact and initially describe it without sensitive attachments.

This repository does not authorise invasive testing of the live website. A hidden file or an ignore rule is not proof of safety. Inspect every proposed addition and its history; removing a secret from the latest file does not remove earlier exposure.
