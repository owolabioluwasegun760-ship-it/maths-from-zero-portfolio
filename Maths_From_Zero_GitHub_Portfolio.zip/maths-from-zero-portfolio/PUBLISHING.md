# Publish under your own GitHub account

**Suggested name:** `maths-from-zero-portfolio`

**Description:** Product journey and engineering case studies for an AI-assisted mathematics learning, teaching-resource and competition platform.

**Topics:** education, mathematics, edtech, portfolio, javascript, supabase, ai-assisted-development.

**Website:** https://maths-from-zero-learning.okeabiodun81.chatgpt.site

**Initial commit:** `Document Maths From Zero product journey and engineering case studies`

### Preferred route

Connect the GitHub account you want to own the portfolio, confirm the connected account, then resume this task. No GitHub repository URL is supplied because none was created or verified during package preparation. The production source repository must stay separate.

### Manual route

1. Extract the ZIP and open its portfolio folder.
2. Create a new GitHub repository under the intended account. Review public visibility for this documentation package.
3. Upload the folder contents with README.md at the root, rather than uploading only the ZIP or adding an extra wrapper directory.
4. Include the supplied .gitignore and .github templates.
5. Use the actual current commit date. Do not reconstruct historical commits.
6. Add the description, topics and website; review the rendered README, local links and diagrams.
7. Run the safe example tests and pin the repository to your profile if desired.

No open-source licence is supplied. Public portfolio visibility is not a grant of rights to the full platform or protected teaching materials.

Official reference: https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository
